---
name: "kamkm chess interface prototype"
description: "Source-derived visual record for the disposable KHA-12 comparison."
colors:
  paper: "oklch(0.22813 0.020366 307.469)"
  surface: "oklch(0.267101 0.02016 311.799)"
  ink: "oklch(0.980735 0.004092 301.426)"
  dim: "oklch(0.880303 0.03077 342.696)"
  rule: "oklch(0.266943 0.015262 302.425)"
  green: "oklch(0.460685 0.185347 4.099)"
  soft: "oklch(0.313674 0.030572 310.061)"
  focus: "oklch(0.591646 0.217985 0.584)"
  warning: "oklch(0.836861 0.164422 84.429)"
  warning-bg: "oklch(0.321706 0.036256 60.806)"
  error: "oklch(0.901233 0.057189 343.694)"
  error-bg: "oklch(0.259022 0.04799 340.062)"
  accent-foreground: "oklch(0.901233 0.057189 343.694)"
  accent-surface: "oklch(0.364912 0.050794 308.491)"
  accent-surface-foreground: "oklch(0.964695 0.009139 341.803)"
  input-border: "oklch(0.266817 0.02897 344.461)"
  message-surface: "oklch(0.273791 0.025541 309.079)"
  placeholder: "oklch(0.657087 0.028226 307.985)"
  sidebar: "oklch(0.185778 0.019368 322.159)"
  sidebar-border: "oklch(0.269132 0.030766 351.067)"
  sidebar-control-surface: "oklch(0.23366 0.026081 338.196)"
  sidebar-foreground: "oklch(0.967434 0.001326 286.375)"
  sidebar-muted-foreground: "oklch(0.880303 0.03077 342.696)"
  sidebar-row-active: "oklch(0.23366 0.026081 338.196)"
  surface-overlay: "oklch(0.154761 0.01316 338.901)"
  surface-raised: "oklch(0.279864 0.021572 309.532)"
  terminal-scrollbar: "oklch(0.266817 0.02897 344.461)"
  toolbar: "oklch(0.22813 0.020366 307.469)"
  toolbar-control: "oklch(0.313674 0.030572 310.061)"
  toolbar-control-hover: "oklch(0.364912 0.050794 308.491)"
  update-foreground: "oklch(0.901233 0.057189 343.694)"
  board-light: "#eeeed2"
  board-dark: "#769656"
  board-coordinate: "#55743c"
  board-hover: "#c3d08f"
  board-focus: "#913b00"
  board-selection: "#793507"
  board-last-move: "#e9e46f88"
  piece-white: "#ffffff"
  piece-white-outline: "#343a35"
  piece-black: "#2c302e"
  piece-black-outline: "#111111"
  piece-black-detail: "#dddddd"
  t3-code-light-canvas: "#fcfcfc"
  t3-code-light-accent: "#1b4ed8"
  t3-code-dark-canvas: "#0a0a0a"
  t3-code-dark-accent: "#346bf1"
  t3-chat-light-canvas: "oklch(0.982446 0.010114 325.653)"
  t3-chat-light-accent: "oklch(0.591646 0.217985 0.584)"
  grove-light-canvas: "oklch(0.972369 0.005497 157.15)"
  grove-light-accent: "oklch(0.523295 0.112292 158.089)"
  grove-dark-canvas: "oklch(0.260865 0.02152 162.75)"
  grove-dark-accent: "oklch(0.796228 0.133058 157.319)"
  ocean-light-canvas: "oklch(0.974199 0.002856 241.597)"
  ocean-light-accent: "oklch(0.536684 0.120219 247.01)"
  ocean-dark-canvas: "oklch(0.242641 0.024125 250.573)"
  ocean-dark-accent: "oklch(0.758933 0.105833 241.548)"
  ember-light-canvas: "oklch(0.976527 0.002685 60.725)"
  ember-light-accent: "oklch(0.552831 0.129438 44.656)"
  ember-dark-canvas: "oklch(0.245899 0.019144 42.044)"
  ember-dark-accent: "oklch(0.762174 0.124117 52.082)"
  iris-light-canvas: "oklch(0.976531 0.003855 303.226)"
  iris-light-accent: "oklch(0.525348 0.15373 294.176)"
  iris-dark-canvas: "oklch(0.225975 0.031062 293.741)"
  iris-dark-accent: "oklch(0.671712 0.169136 293.929)"
typography:
  headline:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "21px"
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: "-0.02em"
  title:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "19px"
    fontWeight: 600
    lineHeight: 1.35
    letterSpacing: "-0.02em"
  section:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "14px"
    fontWeight: 600
    lineHeight: 1.4
    letterSpacing: "-0.02em"
  body:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "12px"
    fontWeight: 500
    lineHeight: 1.5
  note:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "10px"
    fontWeight: 400
    lineHeight: 1.5
  clock:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
    fontSize: "27px"
    fontWeight: 400
    lineHeight: 1.1
    letterSpacing: "-0.04em"
  mono:
    fontFamily: "ui-monospace, 'SF Mono', Consolas, monospace"
    fontSize: "0.88em"
rounded:
  square: "0"
  board: "4px"
  badge: "5px"
  clock: "6px"
  avatar: "7px"
  control: "8px"
  panel: "10px"
  container: "12px"
  circle: "50%"
spacing:
  xs: "4px"
  action-gap: "7px"
  sm: "8px"
  row-gap: "10px"
  md: "12px"
  field-gap: "14px"
  lg: "16px"
  compact-page: "18px"
  section: "20px"
  panel: "24px"
components:
  button-primary:
    backgroundColor: "{colors.green}"
    textColor: "{colors.accent-foreground}"
    rounded: "{rounded.control}"
    padding: "8px 12px"
  button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "8px 12px"
  button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "8px 12px"
  input:
    backgroundColor: "{colors.toolbar-control}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "9px 11px"
  navigation-row:
    backgroundColor: "transparent"
    textColor: "{colors.sidebar-muted-foreground}"
    rounded: "{rounded.control}"
    padding: "8px 10px"
  badge:
    backgroundColor: "{colors.soft}"
    textColor: "{colors.dim}"
    rounded: "{rounded.badge}"
    padding: "3px 7px"
  match-panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.panel}"
  pending-band:
    backgroundColor: "{colors.warning-bg}"
    textColor: "{colors.warning}"
    rounded: "{rounded.control}"
    padding: "13px"
  player-clock:
    backgroundColor: "{colors.surface-raised}"
    textColor: "{colors.dim}"
    typography: "{typography.clock}"
    rounded: "{rounded.clock}"
    padding: "5px 10px"
  board-square:
    backgroundColor: "{colors.board-light}"
    rounded: "{rounded.square}"
---

# Design System: kamkm chess interface prototype

## Overview

**Creative North Star: "Chess.com structure, T3 Code workspace"**

The prototype combines ordinary Chess.com board, player, clock, and game-detail organization with T3 Code's compact workspace styling. The owner explicitly selected the source system typography and actual built-in palettes. Seasonal Halloween bots, artwork, and pieces are excluded.

This record describes the built disposable prototype for KHA-12, not an approved production identity or stack. A, B, and C remain structural alternatives awaiting owner selection. The common controls, palette roles, board, and responsive navigation are the reusable evidence.

**Key Characteristics:**

- A conventional green and ivory board stays independent of the chosen workspace palette.
- Compact system type, thin borders, and tonal surfaces organize the workspace.
- Committed, producing, and queued opponent states remain distinct.
- Prototype comparison controls occupy a reserved footer outside the scrolling product.

Ground truth is [prototype/index.html](prototype/index.html) and [prototype/t3-palettes.js](prototype/t3-palettes.js). PRODUCT.md and the direction contracts explain the owner's pinned references. The scoped finish verdict resolves F1-F3; it covers those fixes rather than whole-product acceptance. No live provider, persistence, complete rules-engine, assistive-technology, full contrast, or native-device certification follows from this document.

## Colors

The workspace uses six source palettes, each with light and dark modes. T3 Chat dark is the initial rendered default. Frontmatter local-role tokens describe that default, not the pre-script CSS fallback colors. Mode-specific canvas and accent entries identify the other shipped choices; their complete semantic objects remain in the palette source.

### Primary

The green token is the selected palette's accent. It fills primary actions and active option buttons, colors small activity marks, and marks active tab edges. Accent foreground supplies the paired text color. Focus is a separate source role and can differ from accent. Accent surface and its foreground supply the opponent emblem.

### Secondary

Soft is the palette's secondary surface. Message surface distinguishes attributed conversation, disclosures, and the running clock. Warning and warning background identify pending handoffs and recovery notices. Error and error background identify failed states. These are semantic statuses, not additional brand accents.

### Neutral

Paper is the canvas, surface is the main panel material, ink is ordinary text, dim is supporting text, and rule is the standard divider. Sidebar roles stay separate from page roles. Toolbar control, input border, placeholder, raised surface, overlay, and update foreground retain their source assignments.

Board-light and board-dark are fixed ivory and green. Board-coordinate is the coordinate color on light squares; dark-square coordinates use board-light. The remaining board tokens record hover, inward focus, selection, and last-move treatments. White and black SVG pieces keep their paired fill and outline tokens.

### Shipped palette choices

| Palette | Light canvas / accent tokens | Dark canvas / accent tokens |
| --- | --- | --- |
| T3 Code | t3-code-light-canvas / t3-code-light-accent | t3-code-dark-canvas / t3-code-dark-accent |
| T3 Chat | t3-chat-light-canvas / t3-chat-light-accent | paper / green |
| Grove | grove-light-canvas / grove-light-accent | grove-dark-canvas / grove-dark-accent |
| Ocean | ocean-light-canvas / ocean-light-accent | ocean-dark-canvas / ocean-dark-accent |
| Ember | ember-light-canvas / ember-light-accent | ember-dark-canvas / ember-dark-accent |
| Iris | iris-light-canvas / iris-light-accent | iris-dark-canvas / iris-dark-accent |

Light, Dark, and System are separate appearance controls. System resolves the operating-system preference; the palette selection remains unchanged. The prototype carries theme and appearance in its URL.

### Semantic mapping and provenance

The theme application exports each source role as a `--t3-<role>` custom property. Its local aliases are:

| Local alias | T3 role |
| --- | --- |
| paper | canvas |
| surface | surface |
| ink | text |
| dim | textMuted |
| rule | border |
| green | accent |
| soft | secondary |
| focus | focus |
| warning | warningForeground |
| warning-bg | warningSurface |
| error | errorForeground |
| error-bg | errorSurface |

Other frontmatter names translate source camelCase roles to readable slugs, such as message-surface for messageSurface and sidebar-row-active for sidebarRowActive. The controls consume those matching `--t3-*` properties directly. Board and piece colors are authored prototype values, independent of T3 palette roles.

Palette source is `D:/projects/T3code/packages/shared/src/themePalettes.ts`, checkout `9503155da67add4fbd7fbc51c99ec19a0c8c4a2c`, SHA-256 `82385050b8b691ff280efc0e93ea9dd8a4bbfd64a4c50cf8536b5c15d1e74479`. The extracted values retain their native hex or OKLCH strings in prototype/t3-palettes.js. [prototype/T3-Code-MIT.txt](prototype/T3-Code-MIT.txt) carries the T3 Tools Inc. MIT notice. Typography and compact geometry were derived from `D:/projects/T3code/apps/web/src/index.css`; theme behavior also references `components/settings/ThemeSettings.tsx`.

Normal-layout references are [Chess.com analysis](https://www.chess.com/analysis), [board sizing](https://support.chess.com/en/articles/8609533-how-do-i-change-my-board-size), and [analysis board help](https://support.chess.com/en/articles/8583825-how-do-i-use-the-analysis-board), inspected on 2026-10-16. The SVG pieces and interface icons are authored inline paths rather than copied seasonal assets. No raster asset is part of the interface.

**The palette-role rule.** Apply the complete selected T3 palette and mode through semantic roles. The historical green alias means accent, even when that accent is magenta, blue, orange, or violet.

**The stable board rule.** Theme changes recolor the workspace, not the standard green and ivory board or the white and black piece identities.

## Typography

Headings, body, and controls share the source system sans stack. This is an explicit owner choice from T3 Code. There is no separate display face or hero type scale. Body text has a 70ch maximum paragraph width. Monospace identifies exact technical strings and wraps long values.

### Hierarchy

- Headline is the compact page heading role. Setup headings also use this size on mobile.
- Title is the section heading role. Drawer headings use a nearby built value of 20px.
- Section is the small heading role within forms and panels.
- Body is the inherited page text role. Cards and forms commonly step down to 13px or 12px.
- Label is the field and control label role. Navigation uses 13px on the full sidebar.
- Note is dense metadata. Smaller captions in the prototype also use 9px, and clock-side labels use 8px. Those smaller sizes are recorded as current details, not a new general-purpose text scale.
- Clock uses tabular numerals and tight tracking. Mobile clocks reduce to 24px.
- Mono uses the code stack and a relative size so exact identifiers sit within their surrounding text hierarchy.

**The source type rule.** Use the compact system sans stack for headings and controls, as explicitly selected by the owner. Reserve monospace for exact model IDs, endpoints, FEN, and code.

## Layout

The normal desktop frame has a fixed navigation sidebar at 218px, a 33px prototype notice strip, and a 52px workspace toolbar. The main page centers within a 1530px maximum width and uses compact gutters. Repeated spacing is intentionally dense. The frontmatter captures the reused gaps and padding values, not an invented arithmetic scale.

A, Classic workspace, places the board beside an opponent panel with Moves, Conversation, and Usage tabs. Its main grid uses a board track of 330px to 650px and a panel track of 280px to 360px, separated by 24px. B, Conversation desk, keeps attributed model conversation in the permanent companion panel and moves opponent details into a horizontal setup band. C, Focused play, uses Board, Opponent, and History task tabs within a centered 1000px limit. These are alternatives, not a single approved composition.

The board is square. Desktop board caps respond to available viewport height: A uses the smaller of 650px and 100dvh minus 360px, B uses 650px and 100dvh minus 400px, and C uses 620px and 100dvh minus 420px. Player rows and clocks sit directly above and below it. Board actions and coordinate move entry remain in the board column.

At 1600px and above, A's main gap expands to 32px. At 1180px and below, the sidebar narrows to 180px and page gutters and panel spacing contract. At 960px and below, it becomes a 64px icon rail and recent-game text is hidden. At 720px and below, the persistent sidebar disappears, the menu control appears, the toolbar becomes 48px high, and A/B stack their panels below the board. Setup steps become a horizontal scrollable row; forms use 18px card padding. Mobile text inputs use 16px to support touch entry.

The corrected comparison control occupies a reserved 82px footer. The product's scroll area is 100dvh minus that reservation; the sidebar also stops above it. The footer sits outside product scrolling, with a separator and the compact A/B/C control. Focused product targets scroll within the area above the footer. This footer is prototype review tooling, not a product navigation commitment.

## Elevation & Depth

The workspace is mostly flat. Palette changes between canvas, sidebar, panels, message blocks, and active rows provide depth, with one-pixel dividers to define edges. There is no card-hover lift. The running clock has an inset accent edge; overlay panels and SVG pieces are the limited cast-shadow uses.

### Shadow vocabulary

- Dialog shadow uses `0 14px 40px #00000040`.
- Drawer shadow uses `-10px 0 35px #0003`.
- Piece relief uses `drop-shadow(0 1px .6px #0005)`.
- Running-clock emphasis uses `inset 0 -2px var(--green)`.
- Drawer and dialog backdrops use `#0008`.

**The tonal depth rule.** Use palette surfaces and one-pixel dividers for ordinary workspace depth. Reserve cast shadows for overlays and the small piece relief already present in the board.

Pending feedback enters with the source's short arrival animation, 250ms with cubic-bezier(.16,1,.3,1), translating 4px into place. Reduced-motion preference removes animations and transitions. No general animation or hover-transition system is established.

## Shapes

Controls use softly rounded corners, panels use a slightly larger radius, and task containers and dialogs use the largest repeated radius. Token names preserve these roles. Badges are small rounded rectangles rather than pills. Circular shapes are limited to status dots, swatches, and similar small identity marks.

The board's outer clip is subtly rounded, while its sixty-four squares meet edge to edge with square corners. On mobile, the board clip tightens to 3px. Player avatars and clocks have compact, distinct radii. Interface SVGs use rounded line caps and joins, typically at 17px with a 1.7 stroke; the board uses its own filled piece geometry.

## Components

### Buttons

Primary actions use the selected accent with its paired foreground. Secondary actions are transparent with a one-pixel rule border. Quiet actions remove that visible border. The standard button has a 38px minimum height; small actions use 32px. Regular hover uses toolbar-control-hover. Primary hover uses a brightness filter of 1.08. Disabled controls use dim text, soft background, and 0.6 opacity. Focus uses a two-pixel source focus outline offset three pixels from the control.

### Chips

Badges use dim text, soft material, a thin rule border, the badge radius, and compact frontmatter padding. Warning and error variants replace that pair with the matching status foreground and background and remove the visible border. Badges describe state; they are not the primary action pattern.

### Cards / Containers

The match panel uses surface, a one-pixel rule border, panel radius, and clipped contents. Its header, opponent block, tabs, and footer use internal separators. Body padding is usually 16px. Task containers use the container radius and 24px padding on desktop. Attributed conversation text sits on message-surface blocks within the retained-history region.

### Inputs / Fields

Fields use toolbar-control background, ink text, input-border, and control radius. Their minimum height is 40px. Read-only fields use soft background and dim text. Placeholder and caret colors follow their semantic roles. Text areas have an 88px minimum height and vertical resizing. Input focus uses the common source focus outline. Coordinate move entry becomes a 42px control on mobile.

### Navigation

Sidebar rows use compact system labels, muted sidebar text, and no visible resting border. Hover and current state use sidebar-row-active with sidebar-foreground. Labels collapse at the icon-rail breakpoint. Tab strips use a two-pixel accent underline and ink for the active task while preserving transparent tab backgrounds. The mobile menu replaces the hidden persistent navigation.

### Board and clocks

Each square is a named native button inside an eight-by-eight grid. Authored SVG pieces occupy 88% of their square with a desktop cap of 65px. Coordinates sit in the square corners. A selected square has an inset border, the last move has a yellow overlay, and board focus uses its own inward outline. Clock numerals stay tabular. The running clock gains ink text, message-surface background, and an inset accent edge. Board semantics and keyboard paths remain subject to later complete screen-reader acceptance.

### Queued opponent feedback

The warning-colored pending band names the queued candidate and its check/first-response status. It keeps the committed identity visible separately, with the producing identity where a reply is active. It offers explicit cancel and check actions. C's Opponent task includes this band and directs focus to it after queueing. It does not announce a committed switch before the candidate's first reply completes.

### Appearance chooser

The two-column choice grid shows source palette names and four overlapping circular swatches for sidebar, canvas, message-surface, and accent. The selected palette has an inward two-pixel accent outline. Light, Dark, and System controls remain distinct from the palette grid.

## Do's and Don'ts

### Do:

- Do apply the selected palette as a full semantic object, including its sidebar, input, message, status, and overlay roles.
- Do keep the authored SVG pieces and green and ivory board stable across themes.
- Do distinguish committed, producing, and pending opponents with explicit text as well as visual state.
- Do preserve a visible focus destination after task changes and keep focused product controls inside the scrolling area above the comparison footer.
- Do keep A, B, and C documented as review alternatives until the owner chooses a structure.

### Don't:

- Don't replace the actual T3 palette data with approximate hex recolorings or use the green alias as a fixed green brand color.
- Don't introduce Halloween bots, seasonal artwork, or seasonal pieces.
- Don't infer a production stack, final layout approval, screen-reader acceptance, contrast acceptance, or native-browser acceptance from these prototype records.

Not canonized: the build's 8px and 9px auxiliary text sizes are not promoted into a general text scale. Their legibility, full contrast, complete screen-reader play, and required native-browser behavior remain acceptance work. The scoped F1-F3 verdict resolves the reported handoff, focus-continuity, and footer-coverage defects; this documentation does not repair UI code or widen that verdict.
