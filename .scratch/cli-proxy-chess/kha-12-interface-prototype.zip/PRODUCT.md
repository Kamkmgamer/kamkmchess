# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Production stack and license remain open in the architecture decision. This branch contains a disposable interface prototype, using plain HTML, CSS, and JavaScript under the owner's delegation of routine defaults. It is not a production stack choice.

## Users

Casual chess players who are curious about AI and bring their own AI-provider credentials or endpoint. They use desktop keyboard/mouse or mobile touch. Complete screen-reader play is an owner-confirmed MVP requirement.

## Product Purpose

Let a person configure an AI connection, select a model, and play chess against a model that chooses its own moves. The current planning effort must produce a build-ready specification before production implementation.

## Positioning

Players can change the model and connection during a match. The new model receives the full retained attributed conversation, including returned plans, and independently chooses whether to continue that plan.

## Operating Context

The public website runs the game controller and direct AI requests in the browser. Hosted accounts and storage provide optional game sync. Guest games are saved locally. AI credentials are saved on the current device by default and are never synced to the chess backend.

Required launch platforms are Windows Chrome/Edge/Firefox, macOS Safari, iOS Safari, and Android Chrome. Responsive prototype review does not establish native browser or provider compatibility.

## Capabilities and Constraints

Connections cover OpenAI, OpenRouter, native Anthropic, and custom endpoints, including CLIProxyAPI. Protocol, model family, exact routing ID, and connection identity are separate. Show every advertised model and allow exact manual IDs. Catalog success does not prove generation.

New-game compatibility checks precede clocks. Midgame switches check new or changed selections and can reuse an unchanged current-session pass. Active replies finish before queued switches, unless explicit Stop, Undo, or expiry fences the response. Failed handoffs require explicit recovery.

Clocks keep running through thinking, failures, switching, navigation, and recovery. Undo rewinds the board, selection, and retained conversation without refunding time. Discarded continuations remain in a separate archive. Final results stay final. Post-loss practice is explicitly unscored, with fresh context and clocks.

Support custom starting positions, explicit promotion, rule-specific illegal-move correction, separate formatting recovery, time/draw results, guest recovery, and optional account sync. A rules component validates moves but never chooses one for a model. Chat with the opponent is outside scope.

Keep provider disclosures visible before the first request, explain quota/credit consequences, and provide local credential replacement/forgetting/clear-all. No provider-terms enforcement allowlist, silent model substitution, history trimming, or application-owned generation relay.

Prompt-cache support and honest usage/cost reporting are required. Actual affordability, per-game budget, and cold/warm cache evidence remain acceptance work.

## Brand Commitments

The owner requested the normal Chess.com website layout combined with T3 Code's interface styling and themes. Seasonal Halloween bot presentation, artwork, and pieces are excluded. Use ordinary board/player/clock and side-panel organization with T3 Code's compact navigation, controls, surfaces, typography, and actual built-in theme palettes. This replaces the initial provisional club-table visual direction.

## Evidence on Hand

Linear is canonical. The parent map is https://linear.app/kamkm/issue/KHA-5. The current interface ticket is https://linear.app/kamkm/issue/KHA-12. Resolved connection, catalog, move, lifecycle, and custom-position decisions are linked there. Existing reports in research/ contain bounded source and synthetic browser evidence, not live model certification.

The prototype uses synthetic model IDs, replies, usage, account state, and demo credentials. It sends no provider/account requests and saves no real credentials. The owner pinned the visual references during this interface session. The normal Chess.com analysis page and official help screenshots were inspected. T3 Code theme definitions were read from D:/projects/T3code/packages/shared/src/themePalettes.ts, with compact UI geometry and font stacks from apps/web/src/index.css.

## Product Principles

- Models choose moves; the application validates them.
- Preserve the full retained conversation and distinguish it from archived undone lines.
- Show the actual clock, request, connection, and recovery status without implying stronger evidence.
- Keep player-controlled AI credentials on the player's device.

## Accessibility & Inclusion

The owner requires complete screen-reader play in addition to keyboard, mouse, and touch. Include named squares and pieces, keyboard move selection, accessible promotion, and concise turn/error announcements. Prototype semantic behavior and specify later assistive-technology acceptance; do not claim unperformed screen-reader or native-device tests.
