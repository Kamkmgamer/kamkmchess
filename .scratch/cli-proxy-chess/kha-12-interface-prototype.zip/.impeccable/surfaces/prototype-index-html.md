---
version: 1
slug: "prototype-index-html"
primary_target: "prototype/index.html"
related_targets: []
---

# Match interface prototype

Disposable review for https://linear.app/kamkm/issue/KHA-12. Visitor mode: Operate. PRODUCT.md holds confirmed scope, including complete screen-reader play and the owner's visual direction. Production implementation and stack remain outside this ticket.

## Direction contract

THESIS: Normal Chess.com playing structure meets T3 Code's workspace. A large conventional board, player rows, and clocks sit beside explicit opponent/request/history state. No seasonal bots or Halloween styling.

OWN-WORLD: Use T3 Code's actual semantic palettes, light/dark variants, system font stack, compact navigation, 52px toolbar, 8px controls, and low-contrast surface hierarchy. A classic green/ivory board and simple authored Staunton SVG pieces remain consistent across themes.

STORY: Set up a player-controlled connection, choose an exact model, check it visibly, then play. The right panel makes the active producing request, committed opponent, queued candidate, and retained history distinguishable. Read-only model history is not a chat feature.

FIRST VIEWPORT: A narrow T3-style game sidebar, compact toolbar with theme control, the board and both player clocks, and a right-hand opponent/moves/conversation panel. B makes the attributed conversation the permanent side panel. C removes that persistent panel in favor of focused board/task tabs. The signature interaction keeps a switch pending until the active reply settles and the candidate's first reply completes.

FORM: Owner-pinned hybrid of ordinary Chess.com structure and T3 Code styling/themes. This supersedes grounded direction 7 and seed 7c4158a5; user direction takes precedence over the roll. The three arrangements remain review options, not final product approval.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Reference evidence

- https://www.chess.com/analysis, ordinary green/ivory board, player rows, navigation, and right panel, inspected 2026-10-16. The seasonal computer-bot page was explicitly rejected by the owner.
- https://support.chess.com/en/articles/8609533-how-do-i-change-my-board-size and https://support.chess.com/en/articles/8583825-how-do-i-use-the-analysis-board, official normal-layout screenshots and layout descriptions.
- D:/projects/T3code/packages/shared/src/themePalettes.ts, SHA-256 82385050b8b691ff280efc0e93ea9dd8a4bbfd64a4c50cf8536b5c15d1e74479. Source checkout HEAD 9503155da67add4fbd7fbc51c99ec19a0c8c4a2c. Extracted palette data is shipped with its MIT notice.
- D:/projects/T3code/apps/web/src/index.css and components/settings/ThemeSettings.tsx, compact geometry, system typography, theme variants, and palette-choice behavior.

## Review boundary

Requests, credential saving, guest/account sync, game endings, and recovery are synthetic fixtures. No real provider calls or credentials. This is an interaction prototype with no complete chess-rules engine, persistence, native-browser certification, or actual screen-reader acceptance. Review semantic/input behavior and fidelity to settled policy; do not equate simulation with verified product support.
