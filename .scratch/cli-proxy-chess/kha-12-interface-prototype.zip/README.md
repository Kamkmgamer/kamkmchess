# Disposable match interface prototype

Question: which arrangement makes connection setup, opponent selection, play, and recovery understandable for a casual player?

Primary source for [Validate the connection and chess match interface](https://linear.app/kamkm/issue/KHA-12). This branch must not be merged into main as production code. The owner requested normal Chess.com layout with T3 Code styling and themes, explicitly excluding Halloween bots and other seasonal presentation.

Run from this worktree:

```powershell
python -m http.server 4182 --bind 127.0.0.1 --directory prototype
```

Open http://127.0.0.1:4182/?variant=A&theme=t3-chat&appearance=dark. The floating switcher compares A, Classic workspace; B, Conversation desk; and C, Focused play. The toolbar's Appearance control switches T3 Code, T3 Chat, Grove, Ocean, Ember, and Iris palettes in light/dark/system mode. Layout, theme, and mode are shareable URL parameters. State otherwise stays in memory and is discarded on reload.

The normal Chess.com analysis page and official help screenshots were inspected as layout references. Palette roles were extracted from `D:/projects/T3code/packages/shared/src/themePalettes.ts`; system typography and compact geometry were checked against `apps/web/src/index.css`. Theme data is accompanied by T3 Code's MIT notice at `prototype/T3-Code-MIT.txt`. The chess pieces are simple authored SVG interface symbols. No Chess.com branding, seasonal artwork, bot avatars, or rating claims are copied.

Use Review a scenario for connection setup, catalog failure/partial results, removed IDs, thinking, queued/failed switching, chess versus formatting recovery, network/capacity failure, promotion, custom starts, saved-game expiry, cross-device credentials, final losses/draw, and synthetic usage. Finish demo reply completes the current scripted response. From the initial position fixture, try f1c4 by clicking squares or using coordinate entry.

Keyboard users can Tab into the board, navigate with arrows, and use Enter/Space for origin and destination. Coordinate input is an alternate path. Promotion requires an explicit piece. Drawers trap and restore focus; Escape closes them. Clocks are not announced every second. Full screen-reader play is owner-confirmed scope, with real assistive-technology acceptance still required.

No provider, authentication, or account-sync request is made. Keys are read-only demo values. Saving and recovery are simulated. This does not implement full chess legality, real credential storage, actual closed-tab recovery, measured compatibility, cache hits, or affordability. Production architecture, storage, and license decisions remain open.

Open `.impeccable/review/review.html` for an offline desktop/mobile comparison. The live links require the server above. The comparison footer reserves its own space below the scrolling product and includes a State inspector.

The finish reviewer scored F1, F2, and F3 resolved in `.impeccable/review/finish-verdict-1.json`. This covers queued-opponent feedback, DOM-inspected focus continuity, and the unobscured comparison footer. It is not a whole-product or assistive-technology acceptance result.

The canonical ticket holds the owner's feedback and resolution. It remains In Progress until the owner reviews the layouts. PRODUCT.md and the surface brief capture this branch's scope and direction, not a production stack choice.
